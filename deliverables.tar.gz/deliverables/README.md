# Deliverables

This directory contains all deliverables required for static code analysis and code coverage.

## Project-Reports

This directory contains all reports generated during the Maven build of the project. To open the reports perform the following steps:
* Open a browser and pass in the full path to the index.html file. Below is an example
* /Users/RobertThompson/Documents/GitHub/chess/deliverables/project-reports/index.html
* Once that file is loaded into the browser, navigate to 'Project Reports' on the left hand side.
* To view the final output from SpotBugs, select the 'SpotBugs' hyperlink.
* To view the final Code Coverage, select the 'JaCoCo' hyperlink.

## Spotbugs-Progression

This directory contains the progression of bugs added and removed throughout the development process.
There are 16 different reports with the 13th report indicating there is no bugs found using SpotBugs.